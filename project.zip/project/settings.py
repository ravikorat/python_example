import os

BASE_URL='https://www.universal-tutorial.com'
API_HEADER = {
    "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyIjp7InVzZXJfZW1haWwiOiJhZG1pbmFAZWNvbW1lcmNlLmNvbSIsImFwaV90b2tlbiI6IkdCME5VWkRGLXVuS1RXZXkxTTkyeXdHSU5ZRWxSLVpvVG1UbHFRTER5NDJRMjYwLW95STF6V0pKM3NjUGkzajk4RGcifSwiZXhwIjoxNjE3NDMwNzg2fQ.qeyMKEY_Ac9si1tsAAJeFP1exXRDNjSK6HTSlir67js",
    "Accept": "application/json"
}
DIRECTORY= os.path.dirname(os.path.abspath(__file__))
CACHE_DIR= os.path.join(DIRECTORY,'Cache')
STATE_DIR = os.path.join(CACHE_DIR,'states')
CITY_DIR = os.path.join(CACHE_DIR,'cities')
country_json= os.path.join(CACHE_DIR,'countries.json')
COUNTRY_NEW_JSON=os.path.join(CACHE_DIR,'getCountry.json')