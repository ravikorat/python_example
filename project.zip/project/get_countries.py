import os
import requests
import json
from settings import BASE_URL,API_HEADER,DIRECTORY,CACHE_DIR,COUNTRY_NEW_JSON


def getCountries():
    with open(COUNTRY_NEW_JSON,'r+') as country_file:
        return[countries['country_name']for countries in json.load(country_file)]
            
    

def getStates(country):
    state_response = requests.get(BASE_URL+'/api/states/'+country,headers=API_HEADER).json()
    with open(COUNTRY_NEW_JSON,'r+') as state_file:
        state=json.load(state_file)
        for country in state:
            if country["country_name"].lower()==country_name: country['states']=state_response
                    # print(country)
        state_file.seek(0)
        json.dump(state,state_file,indent=4)
            
          
def getCities(country_name,state_name):
    with open(COUNTRY_NEW_JSON,'r+') as country_file:
        data=json.load(country_file)
        for country in data: 
            if country['country_name'].lower()==country_name:
                for state in country["states"]:
                    if state['state_name'].lower()==state_name:
                        if 'cities' not in state.keys():
                            cities_response=requests.get(BASE_URL+'/api/cities/'+state_name,headers=API_HEADER) 
                            if cities_response.ok:
                                state['cities']=cities_response.json()
                            else:
                                return(cities_response,cities_response.json()) 
                        country_file.seek(0)
                        json.dump(data,country_file,indent=4)  
                        return(state['cities'])
                                   
            



if __name__=="__main__":
    if not os.path.exists(CACHE_DIR):
        os.mkdir(CACHE_DIR)
    if not os.path.exists(COUNTRY_NEW_JSON):
        countries=requests.get(BASE_URL+'/api/countries/',headers=API_HEADER).json()
        with open(COUNTRY_NEW_JSON, 'w') as countries_file:
            json.dump(countries,countries_file,indent=4) 
                 
 
    print("1. Get all countries name ")
    print("2. Get states by countries ")
    print("3. Get cities by states ")
    n= int(input("Enter your choise between 1 to 3: "))

    if n == 1:
        getCountries()

    elif n == 2:
        # import pdb; pdb.set_trace()
        country_name =input("Enter country name:").lower()
        if country_name in [country["country_name"].lower() for country in json.load(open(COUNTRY_NEW_JSON,'r'))]:
            getStates(country_name)
        else:
            print("Country name not vaid")
            
    elif n == 3 :
        country_name =input("Enter country name :").lower()
        if country_name in [country["country_name"].lower() for country in json.load(open(COUNTRY_NEW_JSON,'r'))]:
            getStates(country_name)
        else:
            print("Country name not vaid")
        # import pdb; pdb.set_trace()
        state_name=input("Enter State name :").lower()
        for country in json.load(open(COUNTRY_NEW_JSON,'r')):
            if country['country_name'].lower()==country_name:
                for state in country["states"]:
                    if state['state_name'].lower()==state_name:
                        print(getCities(country_name,state_name))
        

    else:
        print("Enter number between 1 to 3")

    
    