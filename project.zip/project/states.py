import os
import sys
import requests
import json
from countries import getCountries
from settings import BASE_URL,API_HEADER,CACHE_DIR,STATE_DIR,country_json

def getStates(country):
    if not os.path.exists(STATE_DIR):
        os.makedirs(STATE_DIR)

    state = 'state_of_'+country.replace(' ','_')+'.json'
    states = os.path.join(STATE_DIR,state)
   
    if not os.path.exists(states):
        state_response = requests.get(BASE_URL+'/api/states/'+country,headers=API_HEADER).json()
        with open(states, 'w') as states_file:
            json.dump(state_response,states_file,indent = 4) 
            return "{0} records found in state of {1} json file".format(len(state_response),country)      
    else:
        return "This file already exist"


if __name__ == "__main__":
    
    country_json = os.path.join(CACHE_DIR,'countries.json')
    # import pdb; pdb.set_trace()
    if not os.path.exists(country_json):
        print(getCountries())
    
    country_name = ' '.join(sys.argv[1:]).lower()
    if country_name in [country["country_name"].lower() for country in json.load(open(country_json,'r'))]:
        print(getStates(country_name))
    else:
       print("Country name not valid")