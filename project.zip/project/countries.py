import os
import requests
import json
from settings import BASE_URL,API_HEADER,DIRECTORY,CACHE_DIR,country_json

def getCountries():
    if not os.path.exists(CACHE_DIR):
        os.mkdir(CACHE_DIR)
    # import pdb; pdb.set_trace()
    
    
    if not os.path.exists(country_json):
        countries=requests.get(BASE_URL+'/api/countries/',headers=API_HEADER).json()
        with open(country_json, 'w') as countries_file:
            json.dump(countries,countries_file,indent=4) 
            print("{} records found in country json file".format(len(countries)))     
    else:
        print("File is already exist")


if __name__=="__main__":
    print(getCountries())