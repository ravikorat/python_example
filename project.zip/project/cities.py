import os
import sys
import requests
import json
from countries import getCountries
from states import getStates
from settings import BASE_URL,API_HEADER,CACHE_DIR,STATE_DIR,CITY_DIR,country_json

def getCities(state):
    
    city= 'City_of_'+state.replace(' ','_')+'.json'
    
    cities=os.path.join(CITY_DIR,city)
    # import pdb; pdb.set_trace()
    if not os.path.exists(cities):
        cities_response=requests.get(BASE_URL+'/api/cities/'+state,headers=API_HEADER).json()
        with open(cities, 'w') as city_file:
            json.dump(cities_response,city_file,indent = 4) 
            return "{0} records found in state of {1} json file".format(len(cities_response),state)      
    else:
        return "This file already exist"
    



if __name__ == "__main__":
    # import pdb; pdb.set_trace()
    if not os.path.exists(STATE_DIR):
        os.makedirs(STATE_DIR)
    if not os.path.exists(CITY_DIR):
        os.makedirs(CITY_DIR)
    if not os.path.exists(country_json):
        getCountries()
        
    name = ' '.join(sys.argv[1:]).lower()
    name=name.split('-')
    country_name=name[0]
    state_name = name[1]
    
    state = 'state_of_'+country_name.replace(' ','_')+'.json'
    state_json=os.path.join(STATE_DIR,state)

    # import pdb; pdb.set_trace()
    if country_name not in [country["country_name"].lower() for country in json.load(open(country_json,'r'))]:
        print("Country name not valid")
    else:
        getStates(country_name)
        if state_name not in [state["state_name"].lower() for state in json.load(open(state_json,'r'))]: 
            print("State name not valid")
        else:
            print(getCities(name[1]))
    